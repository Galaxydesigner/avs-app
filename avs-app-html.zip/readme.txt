# README #

### Getting and Installing the Theme ###

* You need Node.js & Sass installed if you haven't installed it, go ahead and install it first. Once you have Node, Sass and the theme installed, the next step is simple enough.

* Install Dependencies — Open a command prompt/terminal and navigate to your theme's root directory and run this command: npm install - 

* Run sass command(sass --watch sass:css) in the root folder of your theme and it will start generating CSS from Sass and everything else